# Pocket Player for Windows

An ad-free music and video player for your PC. GitHub builds the installer for you.

## Get the app

1. On github.com, create a new repository called `pocket-player-pc` (Private is fine).
2. Tap **uploading an existing file**, upload `pocket-player-desktop.zip` as it is, and **Commit changes**.
3. **Add file › Create new file**, name it `.github/workflows/build-windows.yml`, paste in the contents of `build-windows.yml`, and **Commit changes**.
4. Open **Actions** and wait for **Build Windows app** to show a green tick (about 5–10 minutes).
5. Open **Releases › Pocket Player for Windows**, download **PocketPlayer-Setup-1.0.x.exe** and run it.

Windows SmartScreen warns about apps that aren't code-signed. Click **More info › Run anyway**.

## What it does on a PC

- Finds every song and video in your Music and Videos folders, plus any folder you add with **Add folder**.
- Reads song titles, artists, albums and album art from the files.
- Right-click a music or video file › **Open with › Pocket Player** to play it.
- Keyboard media keys and the Windows media controls work.
- Everything from the web version: equalizer, speed, video tools, themes, favourites, sleep timer and Hearing boost.

## Files

- `main.js`: the desktop window, folder scanning, tags and album art
- `preload.js`: the bridge between the window and the player page
- `www/index.html`: the player
- `build/`: app icon
