// Gives the player page a small, safe set of desktop features.
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('pocketDesktop', {
  platform: process.platform,
  scan: () => ipcRenderer.invoke('scan'),
  folders: () => ipcRenderer.invoke('folders'),
  addFolder: () => ipcRenderer.invoke('add-folder'),
  removeFolder: (folder) => ipcRenderer.invoke('remove-folder', folder),
  takeOpenFiles: () => ipcRenderer.invoke('take-open-files'),
  onTags: (cb) => { ipcRenderer.on('tags', (_e, list) => cb(list)); },
  onOpenFiles: (cb) => { ipcRenderer.on('open-files', (_e, items) => cb(items)); }
});
