'use strict';
// Pocket Player for Windows: wraps the player page in a desktop window, finds music and video
// in your folders, reads song tags and album art, and opens files you double-click.
const { app, BrowserWindow, protocol, ipcMain, dialog, session, shell, Menu } = require('electron');
const path = require('node:path');
const fs = require('node:fs');
const fsp = fs.promises;
const crypto = require('node:crypto');
const { Readable } = require('node:stream');

const WWW = path.join(__dirname, 'www');
const AUDIO = ['mp3', 'm4a', 'aac', 'flac', 'wav', 'ogg', 'oga', 'opus', 'weba', 'aif', 'aiff', 'wma'];
const VIDEO = ['mp4', 'm4v', 'mov', 'webm', 'mkv', '3gp', 'ogv', 'avi', 'wmv'];
const MIME = {
  html: 'text/html; charset=utf-8', js: 'text/javascript', css: 'text/css', json: 'application/json',
  png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ico: 'image/x-icon',
  mp3: 'audio/mpeg', m4a: 'audio/mp4', aac: 'audio/aac', flac: 'audio/flac', wav: 'audio/wav', ogg: 'audio/ogg', oga: 'audio/ogg',
  opus: 'audio/ogg', weba: 'audio/webm', aif: 'audio/aiff', aiff: 'audio/aiff', wma: 'audio/x-ms-wma',
  mp4: 'video/mp4', m4v: 'video/mp4', mov: 'video/mp4', webm: 'video/webm', mkv: 'video/webm', '3gp': 'video/3gpp',
  ogv: 'video/ogg', avi: 'video/x-msvideo', wmv: 'video/x-ms-wmv'
};
const SKIP_DIRS = new Set(['node_modules', '$recycle.bin', 'system volume information', 'appdata', 'windows', 'program files', 'program files (x86)']);

protocol.registerSchemesAsPrivileged([{
  scheme: 'pocket',
  privileges: { standard: true, secure: true, supportFetchAPI: true, stream: true, corsEnabled: true }
}]);

if (!app.requestSingleInstanceLock()) {
  app.quit();
}

let win = null;
let settings = { folders: [] };
let tagCache = {};
let artDir = '';
const allowed = new Set();
let pendingOpen = [];

const ext = (f) => path.extname(f).slice(1).toLowerCase();
const kindOf = (f) => AUDIO.includes(ext(f)) ? 'audio' : VIDEO.includes(ext(f)) ? 'video' : null;
const keyOf = (f) => { const r = path.resolve(f); return process.platform === 'win32' ? r.toLowerCase() : r; };
const mediaUrl = (f) => 'pocket://app/media?p=' + encodeURIComponent(f);
const artUrl = (name) => 'pocket://app/art/' + encodeURIComponent(name);
const dataFile = (n) => path.join(app.getPath('userData'), n);

function readJSON(f, fallback) {
  try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch (e) { return fallback; }
}
function writeJSON(f, v) {
  try { fs.writeFileSync(f, JSON.stringify(v)); } catch (e) { /* ignore */ }
}
const saveSettings = () => writeJSON(dataFile('settings.json'), settings);
let tagSaveTimer = null;
function saveTagsSoon() {
  clearTimeout(tagSaveTimer);
  tagSaveTimer = setTimeout(() => writeJSON(dataFile('tags.json'), tagCache), 1500);
}

/* ---------- serving the page, media files and album art ---------- */
async function serve(file, req) {
  let st;
  try { st = await fsp.stat(file); } catch (e) { return new Response('Not found', { status: 404 }); }
  if (!st.isFile()) return new Response('Not found', { status: 404 });
  const type = MIME[ext(file)] || 'application/octet-stream';
  const range = req.headers.get('range');
  if (range) {
    const m = /bytes=(\d*)-(\d*)/.exec(range);
    let start = 0, end = st.size - 1;
    if (m) {
      if (m[1] === '' && m[2] !== '') { start = Math.max(0, st.size - Number(m[2])); }
      else { start = Number(m[1] || 0); if (m[2] !== '') end = Math.min(Number(m[2]), st.size - 1); }
    }
    if (start >= st.size || start > end) {
      return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${st.size}` } });
    }
    const body = Readable.toWeb(fs.createReadStream(file, { start, end }));
    return new Response(body, {
      status: 206,
      headers: {
        'Content-Type': type, 'Content-Length': String(end - start + 1),
        'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes'
      }
    });
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)), {
    status: 200,
    headers: { 'Content-Type': type, 'Content-Length': String(st.size), 'Accept-Ranges': 'bytes' }
  });
}

function registerProtocol() {
  protocol.handle('pocket', async (req) => {
    const u = new URL(req.url);
    const p = decodeURIComponent(u.pathname);
    if (p === '/media') {
      const f = u.searchParams.get('p') || '';
      if (!allowed.has(keyOf(f))) return new Response('Not allowed', { status: 403 });
      return serve(f, req);
    }
    if (p.startsWith('/art/')) {
      return serve(path.join(artDir, path.basename(p.slice(5))), req);
    }
    if (p === '/vendor/jsmediatags.min.js') {
      try { return serve(require.resolve('jsmediatags/dist/jsmediatags.min.js'), req); }
      catch (e) { return new Response('', { status: 404 }); }
    }
    const rel = p.replace(/^\/+/, '') || 'index.html';
    const full = path.normalize(path.join(WWW, rel));
    if (!full.startsWith(WWW)) return new Response('Not allowed', { status: 403 });
    return serve(full, req);
  });
}

/* ---------- finding music and video ---------- */
async function walk(dir, out, depth) {
  if (depth > 12 || out.length >= 30000) return;
  let entries;
  try { entries = await fsp.readdir(dir, { withFileTypes: true }); } catch (e) { return; }
  for (const e of entries) {
    if (e.name.startsWith('.')) continue;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (!SKIP_DIRS.has(e.name.toLowerCase())) await walk(full, out, depth + 1);
    } else if (e.isFile()) {
      const kind = kindOf(e.name);
      if (kind) out.push({ full, name: e.name, kind });
    }
  }
}

function toItem(full, name, kind, st, cached) {
  return {
    path: full, name, kind, size: st.size, mtime: st.mtimeMs, url: mediaUrl(full),
    title: (cached && cached.title) || '', artist: (cached && cached.artist) || '', album: (cached && cached.album) || '',
    art: cached && cached.art ? artUrl(cached.art) : null
  };
}

function freshTags(k, st) {
  const c = tagCache[k];
  return c && c.size === st.size && c.mtime === st.mtimeMs ? c : null;
}

/* ---------- song tags and album art ---------- */
let jsmediatags = null;
try { jsmediatags = require('jsmediatags'); } catch (e) { jsmediatags = null; }

function readTags(full) {
  return new Promise((resolve) => {
    if (!jsmediatags) return resolve({});
    const timer = setTimeout(() => resolve({}), 10000);
    const done = (v) => { clearTimeout(timer); resolve(v); };
    try {
      jsmediatags.read(full, {
        onSuccess: ({ tags }) => {
          let art = null;
          const pic = tags.picture;
          if (pic && pic.data && pic.data.length) {
            try {
              const buf = Buffer.from(pic.data);
              const name = crypto.createHash('sha1').update(buf).digest('hex').slice(0, 20) + (/png/i.test(pic.format || '') ? '.png' : '.jpg');
              const f = path.join(artDir, name);
              if (!fs.existsSync(f)) fs.writeFileSync(f, buf);
              art = name;
            } catch (e) { art = null; }
          }
          done({ title: tags.title || '', artist: tags.artist || '', album: tags.album || '', art });
        },
        onError: () => done({})
      });
    } catch (e) { done({}); }
  });
}

let tagJob = 0;
async function readTagsLater(list, wc) {
  const job = ++tagJob;
  let batch = [];
  for (const it of list) {
    if (job !== tagJob || wc.isDestroyed()) return;
    const t = await readTags(it.full);
    const entry = { size: it.st.size, mtime: it.st.mtimeMs, title: t.title || '', artist: t.artist || '', album: t.album || '', art: t.art || null };
    tagCache[it.k] = entry;
    batch.push({ path: it.full, title: entry.title, artist: entry.artist, album: entry.album, art: entry.art ? artUrl(entry.art) : null });
    if (batch.length >= 25) {
      if (!wc.isDestroyed()) wc.send('tags', batch);
      batch = [];
      saveTagsSoon();
    }
  }
  if (batch.length && !wc.isDestroyed()) wc.send('tags', batch);
  saveTagsSoon();
}

/* ---------- files opened with "Open with Pocket Player" ---------- */
function mediaArgs(argv) {
  return argv.slice(1).filter((a) => a && !a.startsWith('-') && kindOf(a) && fs.existsSync(a));
}
function itemsFor(paths, wc) {
  const items = [], need = [];
  for (const full of paths) {
    try {
      const st = fs.statSync(full);
      const k = keyOf(full);
      allowed.add(k);
      const cached = freshTags(k, st);
      items.push(toItem(full, path.basename(full), kindOf(full), st, cached));
      if (kindOf(full) === 'audio' && !cached) need.push({ full, k, st });
    } catch (e) { /* skip */ }
  }
  if (need.length && wc) readTagsLater(need, wc);
  return items;
}

/* ---------- messages from the page ---------- */
function registerIpc() {
  ipcMain.handle('folders', () => settings.folders);

  ipcMain.handle('scan', async (event) => {
    const files = [];
    for (const folder of settings.folders) await walk(folder, files, 0);
    const seen = new Set(), items = [], need = [];
    for (const f of files) {
      const k = keyOf(f.full);
      if (seen.has(k)) continue;
      seen.add(k);
      let st;
      try { st = await fsp.stat(f.full); } catch (e) { continue; }
      allowed.add(k);
      const cached = freshTags(k, st);
      items.push(toItem(f.full, f.name, f.kind, st, cached));
      if (f.kind === 'audio' && !cached) need.push({ full: f.full, k, st });
    }
    if (need.length) readTagsLater(need, event.sender);
    return { items, folders: settings.folders };
  });

  ipcMain.handle('add-folder', async () => {
    const r = await dialog.showOpenDialog(win, { title: 'Choose a folder with music or videos', properties: ['openDirectory', 'multiSelections'] });
    if (r.canceled || !r.filePaths.length) return { added: false, folders: settings.folders };
    const have = new Set(settings.folders.map(keyOf));
    for (const f of r.filePaths) if (!have.has(keyOf(f))) settings.folders.push(f);
    saveSettings();
    return { added: true, folders: settings.folders };
  });

  ipcMain.handle('remove-folder', (_e, folder) => {
    settings.folders = settings.folders.filter((f) => keyOf(f) !== keyOf(folder));
    saveSettings();
    return settings.folders;
  });

  ipcMain.handle('take-open-files', (event) => {
    const items = itemsFor(pendingOpen, event.sender);
    pendingOpen = [];
    return items;
  });
}

/* ---------- window ---------- */
function createWindow() {
  const b = settings.bounds || {};
  win = new BrowserWindow({
    width: b.width || 1220, height: b.height || 840, x: b.x, y: b.y,
    minWidth: 380, minHeight: 560,
    backgroundColor: '#101014', title: 'Pocket Player',
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true, show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true, sandbox: true,
      backgroundThrottling: false
    }
  });
  if (settings.maximized) win.maximize();
  win.once('ready-to-show', () => win.show());

  const saveBounds = () => {
    if (!win || win.isDestroyed()) return;
    settings.maximized = win.isMaximized();
    if (!settings.maximized && !win.isMinimized()) settings.bounds = win.getBounds();
    saveSettings();
  };
  win.on('close', saveBounds);

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('pocket://')) {
      e.preventDefault();
      if (/^https?:\/\//.test(url)) shell.openExternal(url);
    }
  });
  win.webContents.on('before-input-event', (e, input) => {
    if (input.type === 'keyDown' && (input.key === 'F12' || (input.control && input.shift && input.key.toLowerCase() === 'i'))) {
      win.webContents.toggleDevTools();
    }
  });

  win.loadURL('pocket://app/index.html');
}

app.on('second-instance', (_e, argv) => {
  if (!win) return;
  if (win.isMinimized()) win.restore();
  win.focus();
  const items = itemsFor(mediaArgs(argv), win.webContents);
  if (items.length) win.webContents.send('open-files', items);
});

app.whenReady().then(() => {
  artDir = dataFile('art');
  fs.mkdirSync(artDir, { recursive: true });
  settings = Object.assign({ folders: null }, readJSON(dataFile('settings.json'), {}));
  if (!Array.isArray(settings.folders)) {
    settings.folders = ['music', 'videos'].map((n) => { try { return app.getPath(n); } catch (e) { return null; } })
      .filter((f) => f && fs.existsSync(f));
    saveSettings();
  }
  tagCache = readJSON(dataFile('tags.json'), {});
  pendingOpen = mediaArgs(process.argv);

  const ok = new Set(['media', 'fullscreen', 'speaker-selection', 'mediaKeySystem', 'clipboard-sanitized-write']);
  session.defaultSession.setPermissionRequestHandler((_wc, perm, cb) => cb(ok.has(perm)));
  session.defaultSession.setPermissionCheckHandler((_wc, perm) => ok.has(perm));

  Menu.setApplicationMenu(null);
  registerProtocol();
  registerIpc();
  createWindow();
});

app.on('window-all-closed', () => {
  writeJSON(dataFile('tags.json'), tagCache);
  app.quit();
});
